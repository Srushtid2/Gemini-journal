import React, { useState, useEffect, useRef } from 'react';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { auth, testFirestoreConnection } from './firebase.ts';
import {
  subscribeToUserMemories,
  createMemoryInFirestore,
  updateMemoryInFirestore,
  deleteMemoryFromFirestore,
  seedStarterMemoriesInFirestore,
  saveMemoryReflection,
  deleteMemoryReflection,
} from './services/memoryService.ts';
import { AuthScreen } from './components/AuthScreen.tsx';
import { Header } from './components/Header.tsx';
import { MemoryCard } from './components/MemoryCard.tsx';
import { MemoryModal } from './components/MemoryModal.tsx';
import { DeleteConfirmModal } from './components/DeleteConfirmModal.tsx';
import { EmptyState } from './components/EmptyState.tsx';
import { Toast, ToastMessage } from './components/Toast.tsx';
import { GeminiChat } from './components/GeminiChat.tsx';
import { Memory, MemoryFormData, ChatMessage, TemporaryMediaAttachment } from './types.ts';
import { ArrowDownUp, RotateCcw, Loader2, BookOpen, CloudCheck, Search, X } from 'lucide-react';

export default function App() {
  // Authentication State
  const [user, setUser] = useState<User | null>(null);
  const [isAuthChecking, setIsAuthChecking] = useState<boolean>(true);

  // Memories & Navigation State (Cloud Firestore)
  const [memories, setMemories] = useState<Memory[]>([]);
  const [sessionMedia, setSessionMedia] = useState<Record<string, TemporaryMediaAttachment[]>>({});
  const sessionMediaRef = useRef<Record<string, TemporaryMediaAttachment[]>>({});
  sessionMediaRef.current = sessionMedia;

  const [isMemoriesLoading, setIsMemoriesLoading] = useState<boolean>(true);
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');
  const [currentView, setCurrentView] = useState<'timeline' | 'chat'>('timeline');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Async Mutation Progress States
  const [isSavingMemory, setIsSavingMemory] = useState<boolean>(false);
  const [isDeletingMemory, setIsDeletingMemory] = useState<boolean>(false);
  const [isSeedingStarter, setIsSeedingStarter] = useState<boolean>(false);
  const [reflectingMemoryId, setReflectingMemoryId] = useState<string | null>(null);

  // Test Firestore connection on boot
  useEffect(() => {
    testFirestoreConnection();
  }, []);

  // Listen to Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setIsAuthChecking(false);
    });

    return () => unsubscribe();
  }, []);

  // Subscribe to user's isolated Firestore memories collection
  useEffect(() => {
    if (!user) {
      setMemories([]);
      setIsMemoriesLoading(false);
      return;
    }

    setIsMemoriesLoading(true);
    const unsubscribe = subscribeToUserMemories(
      user.uid,
      (userMemories) => {
        setMemories(userMemories);
        setIsMemoriesLoading(false);
      },
      (err) => {
        console.error('Firestore memory subscription error:', err);
        setIsMemoriesLoading(false);
        setToast({
          id: String(Date.now()),
          type: 'error',
          title: 'Database Sync Error',
          description: 'Unable to synchronize with Cloud Firestore. Please check your network connection.',
        });
      }
    );

    return () => unsubscribe();
  }, [user]);

  // Cleanup object URLs on unmount to prevent memory leaks
  useEffect(() => {
    return () => {
      (Object.values(sessionMediaRef.current) as TemporaryMediaAttachment[][]).forEach((attachments) => {
        attachments.forEach((att) => URL.revokeObjectURL(att.url));
      });
    };
  }, []);

  // Handle user sign out
  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setToast({
        id: String(Date.now()),
        type: 'info',
        title: 'Signed Out',
        description: 'You have been safely signed out.',
      });
    } catch (err: any) {
      console.error('Sign out error:', err);
    }
  };

  // Chat State
  const [focusedMemory, setFocusedMemory] = useState<Memory | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const [chatError, setChatError] = useState<string | null>(null);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [activeMemory, setActiveMemory] = useState<Memory | null>(null);

  // Delete Dialog State
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [memoryToDelete, setMemoryToDelete] = useState<Memory | null>(null);

  // Notification Toast State
  const [toast, setToast] = useState<ToastMessage | null>(null);

  // Open modal to create a new memory
  const handleOpenCreate = () => {
    setActiveMemory(null);
    setModalMode('create');
    setIsModalOpen(true);
  };

  // Open modal to edit an existing memory
  const handleOpenEdit = (memory: Memory) => {
    setActiveMemory({
      ...memory,
      temporaryMedia: sessionMedia[memory.id] || memory.temporaryMedia || [],
    });
    setModalMode('edit');
    setIsModalOpen(true);
  };

  // Open confirmation dialog to delete a memory
  const handleOpenDelete = (memory: Memory) => {
    setMemoryToDelete(memory);
    setIsDeleteOpen(true);
  };

  // Save (Create or Update) memory directly to Cloud Firestore
  const handleSaveMemory = async (formData: MemoryFormData) => {
    if (!user) {
      setToast({
        id: String(Date.now()),
        type: 'error',
        title: 'Authentication Required',
        description: 'You must be signed in to save memories.',
      });
      return;
    }

    setIsSavingMemory(true);
    try {
      if (modalMode === 'create') {
        const newMemory = await createMemoryInFirestore(user.uid, formData);
        if (formData.temporaryMedia && formData.temporaryMedia.length > 0) {
          setSessionMedia((prev) => ({
            ...prev,
            [newMemory.id]: formData.temporaryMedia || [],
          }));
        }
        setToast({
          id: String(Date.now()),
          type: 'success',
          title: 'Memory Saved',
          description: 'Your memory has been safely preserved in Cloud Firestore.',
        });
      } else if (modalMode === 'edit' && activeMemory) {
        await updateMemoryInFirestore(user.uid, activeMemory.id, formData);
        if (formData.temporaryMedia !== undefined) {
          setSessionMedia((prev) => {
            const existing = prev[activeMemory.id] || [];
            const newUrls = new Set((formData.temporaryMedia || []).map((m) => m.url));
            // Revoke removed attachments
            existing.forEach((att) => {
              if (!newUrls.has(att.url)) {
                URL.revokeObjectURL(att.url);
              }
            });
            return {
              ...prev,
              [activeMemory.id]: formData.temporaryMedia || [],
            };
          });
        }
        // If the edited memory is currently focused in chat, update its reference
        if (focusedMemory && focusedMemory.id === activeMemory.id) {
          setFocusedMemory({
            ...focusedMemory,
            date: formData.date,
            title: formData.title,
            originalText: formData.originalText,
            temporaryMedia: formData.temporaryMedia || [],
          });
        }
        setToast({
          id: String(Date.now()),
          type: 'success',
          title: 'Memory Updated',
          description: 'Changes synchronized with Cloud Firestore.',
        });
      }
      setIsModalOpen(false);
      setActiveMemory(null);
    } catch (err: any) {
      console.error('Error saving memory to Firestore:', err);
      setToast({
        id: String(Date.now()),
        type: 'error',
        title: 'Save Failed',
        description: err.message || 'Could not save memory to Cloud Firestore. Please retry.',
      });
    } finally {
      setIsSavingMemory(false);
    }
  };

  // Confirm delete memory from Cloud Firestore
  const handleConfirmDelete = async () => {
    if (!user || !memoryToDelete) return;

    setIsDeletingMemory(true);
    try {
      await deleteMemoryFromFirestore(user.uid, memoryToDelete.id);

      // Revoke any temporary media URLs associated with this memory
      const mediaToRevoke = sessionMedia[memoryToDelete.id] || [];
      mediaToRevoke.forEach((att) => URL.revokeObjectURL(att.url));
      setSessionMedia((prev) => {
        const next = { ...prev };
        delete next[memoryToDelete.id];
        return next;
      });

      // If deleting the focused memory in chat, clear focus
      if (focusedMemory && focusedMemory.id === memoryToDelete.id) {
        setFocusedMemory(null);
      }

      setToast({
        id: String(Date.now()),
        type: 'info',
        title: 'Memory Deleted',
        description: `"${memoryToDelete.title}" was removed from Cloud Firestore.`,
      });
      setIsDeleteOpen(false);
      setMemoryToDelete(null);
    } catch (err: any) {
      console.error('Error deleting memory from Firestore:', err);
      setToast({
        id: String(Date.now()),
        type: 'error',
        title: 'Delete Failed',
        description: err.message || 'Could not delete memory from Cloud Firestore. Please retry.',
      });
    } finally {
      setIsDeletingMemory(false);
    }
  };

  // Handle Converse Click on a Timeline Memory: Navigate to Chat with this memory focused
  const handleConverseClick = (memory: Memory) => {
    if (!focusedMemory || focusedMemory.id !== memory.id) {
      setChatMessages([]);
    }
    setFocusedMemory(memory);
    setCurrentView('chat');
    setChatError(null);
  };

  // Clear focus in chat
  const handleClearFocus = () => {
    setFocusedMemory(null);
    setToast({
      id: String(Date.now()),
      type: 'info',
      title: 'Focus Cleared',
      description: 'Now conversing across all available journal memories.',
    });
  };

  // Start a new conversation (clears history, starts empty chat)
  const handleNewConversation = () => {
    setChatMessages([]);
    setChatError(null);
    setToast({
      id: String(Date.now()),
      type: 'info',
      title: 'New Conversation',
      description: 'Chat history cleared. Started a fresh conversation.',
    });
  };

  // Send message to Gemini in multi-turn conversation
  const handleSendMessage = async (text: string) => {
    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    const newMessages = [...chatMessages, userMsg];
    setChatMessages(newMessages);
    setIsChatLoading(true);
    setChatError(null);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          focusedMemory: focusedMemory
            ? {
                id: focusedMemory.id,
                date: focusedMemory.date,
                title: focusedMemory.title,
                originalText: focusedMemory.originalText,
              }
            : null,
          allMemories: memories.map((m) => ({
            id: m.id,
            date: m.date,
            title: m.title,
            originalText: m.originalText,
          })),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to receive response from Gemini.');
      }

      const modelMsg: ChatMessage = {
        id: `gem-${Date.now()}`,
        role: 'model',
        content: data.reply || 'No response generated.',
        timestamp: Date.now(),
      };

      setChatMessages((prev) => [...prev, modelMsg]);
    } catch (err: any) {
      console.error('Chat error:', err);
      setChatError(err.message || 'An error occurred while communicating with Gemini.');
    } finally {
      setIsChatLoading(false);
    }
  };

  // Seed or Restore Starter Memories into Firestore
  const handleResetSampleMemories = async () => {
    if (!user) return;
    setIsSeedingStarter(true);
    try {
      await seedStarterMemoriesInFirestore(user.uid);
      setToast({
        id: String(Date.now()),
        type: 'success',
        title: 'Starter Memories Loaded',
        description: 'Loaded 3 starter memories into your private Firestore collection.',
      });
    } catch (err: any) {
      console.error('Error seeding starter memories:', err);
      setToast({
        id: String(Date.now()),
        type: 'error',
        title: 'Seeding Failed',
        description: err.message || 'Could not write starter memories to Cloud Firestore.',
      });
    } finally {
      setIsSeedingStarter(false);
    }
  };

  // Generate on-demand AI Reflection for a memory
  const handleGenerateReflection = async (memory: Memory) => {
    if (!user) return;
    setReflectingMemoryId(memory.id);

    try {
      const response = await fetch('/api/reflect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memory: {
            id: memory.id,
            date: memory.date,
            title: memory.title,
            originalText: memory.originalText,
          },
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate reflection.');
      }

      await saveMemoryReflection(user.uid, memory.id, data.reflection);

      setToast({
        id: String(Date.now()),
        type: 'success',
        title: 'Reflection Saved',
        description: 'AI reflection generated and synchronized with Cloud Firestore.',
      });
    } catch (err: any) {
      console.error('Reflection generation error:', err);
      setToast({
        id: String(Date.now()),
        type: 'error',
        title: 'Reflection Failed',
        description: err.message || 'Could not generate reflection. Please try again.',
      });
    } finally {
      setReflectingMemoryId(null);
    }
  };

  // Remove an AI reflection from a memory
  const handleDeleteReflection = async (memory: Memory) => {
    if (!user) return;
    try {
      await deleteMemoryReflection(user.uid, memory.id);
      setToast({
        id: String(Date.now()),
        type: 'info',
        title: 'Reflection Removed',
        description: 'AI reflection cleared from this memory.',
      });
    } catch (err: any) {
      console.error('Reflection removal error:', err);
      setToast({
        id: String(Date.now()),
        type: 'error',
        title: 'Action Failed',
        description: 'Could not remove reflection.',
      });
    }
  };

  // Merge Firestore memories with in-memory session attachments
  const memoriesWithSessionMedia = memories.map((mem) => ({
    ...mem,
    temporaryMedia: sessionMedia[mem.id] || mem.temporaryMedia || [],
  }));

  // Filter memories by search query, then sort chronologically
  const filteredAndSortedMemories = memoriesWithSessionMedia
    .filter((mem) => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        mem.title.toLowerCase().includes(q) ||
        mem.originalText.toLowerCase().includes(q) ||
        mem.date.includes(q) ||
        (mem.reflection && mem.reflection.toLowerCase().includes(q))
      );
    })
    .sort((a, b) => {
      const dateComparison = a.date.localeCompare(b.date);
      return sortOrder === 'desc' ? -dateComparison : dateComparison;
    });

  // Authentication loading screen
  if (isAuthChecking) {
    return (
      <div className="min-h-screen bg-stone-50 flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 rounded-2xl bg-stone-900 flex items-center justify-center text-white shadow-xs mb-4">
          <BookOpen className="w-6 h-6 text-stone-100" />
        </div>
        <div className="flex items-center gap-2 text-sm text-stone-600 font-medium">
          <Loader2 className="w-4 h-4 animate-spin text-stone-500" />
          <span>Opening your private journal...</span>
        </div>
      </div>
    );
  }

  // Unauthenticated: Show AuthScreen (do not expose timeline or memories)
  if (!user) {
    return (
      <>
        <AuthScreen />
        <Toast toast={toast} onDismiss={() => setToast(null)} />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 flex flex-col font-sans selection:bg-stone-200">
      {/* App Shell Header with view navigation */}
      <Header
        currentView={currentView}
        onNavigate={(view) => setCurrentView(view)}
        onNewMemory={handleOpenCreate}
        memoryCount={memories.length}
        userEmail={user.email}
        onSignOut={handleSignOut}
      />

      {/* Main Content Area */}
      {currentView === 'chat' ? (
        <main className="flex-1 max-w-4xl w-full mx-auto px-2 sm:px-6 py-4 sm:py-6 flex flex-col">
          <GeminiChat
            focusedMemory={focusedMemory}
            allMemories={memories}
            messages={chatMessages}
            isLoading={isChatLoading}
            error={chatError}
            onSendMessage={handleSendMessage}
            onClearFocus={handleClearFocus}
            onBackToTimeline={() => setCurrentView('timeline')}
            onNewConversation={handleNewConversation}
          />
        </main>
      ) : (
        <main className="flex-1 max-w-3xl w-full mx-auto px-4 sm:px-6 py-8">
          {/* Timeline Controls Header */}
          <div className="flex items-center justify-between gap-4 mb-4 pb-4 border-b border-stone-200/80">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold tracking-tight text-stone-900">
                  My Timeline
                </h2>
                <span className="inline-flex items-center gap-1 text-2xs px-2 py-0.5 rounded-full bg-stone-200/70 text-stone-700 font-medium">
                  <CloudCheck className="w-3 h-3 text-emerald-600" />
                  <span>Cloud Synced</span>
                </span>
              </div>
              <p className="text-xs text-stone-500 mt-0.5">
                Personal chronological memory archive
              </p>
            </div>

            <div className="flex items-center gap-2">
              {memories.length > 1 && (
                <button
                  id="sort-toggle-btn"
                  type="button"
                  onClick={() =>
                    setSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'))
                  }
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-200 bg-white hover:bg-stone-100 text-stone-700 text-xs font-medium transition-colors cursor-pointer shadow-2xs"
                  title="Toggle chronological sort order"
                >
                  <ArrowDownUp className="w-3.5 h-3.5 text-stone-500" />
                  <span>{sortOrder === 'desc' ? 'Newest first' : 'Oldest first'}</span>
                </button>
              )}

              {memories.length === 0 && (
                <button
                  id="restore-samples-btn"
                  type="button"
                  onClick={handleResetSampleMemories}
                  disabled={isSeedingStarter}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-200 bg-white hover:bg-stone-100 text-stone-700 text-xs font-medium transition-colors cursor-pointer shadow-2xs disabled:opacity-50"
                >
                  {isSeedingStarter ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-stone-500" />
                  ) : (
                    <RotateCcw className="w-3.5 h-3.5 text-stone-500" />
                  )}
                  <span>Load Starter Memories</span>
                </button>
              )}
            </div>
          </div>

          {/* Search Bar when memories exist */}
          {memories.length > 0 && (
            <div className="mb-6 relative">
              <div className="relative flex items-center">
                <Search className="w-4 h-4 text-stone-400 absolute left-3.5 pointer-events-none" />
                <input
                  id="timeline-search-input"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search memories, themes, dates, or reflections..."
                  className="w-full pl-9 pr-9 py-2 rounded-xl bg-white border border-stone-200 text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-1 focus:ring-stone-400 focus:border-stone-400 shadow-2xs transition-all"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 p-0.5 rounded-full text-stone-400 hover:text-stone-700 transition-colors"
                    title="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              {searchQuery && (
                <div className="mt-1.5 text-xs text-stone-500 pl-1 flex items-center justify-between">
                  <span>
                    Showing {filteredAndSortedMemories.length} of {memories.length} memories
                  </span>
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="text-stone-500 hover:text-stone-800 underline text-xs cursor-pointer"
                  >
                    Clear filter
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Timeline Content */}
          {isMemoriesLoading ? (
            <div className="py-20 text-center text-stone-500 flex flex-col items-center justify-center">
              <Loader2 className="w-6 h-6 animate-spin text-stone-400 mb-2" />
              <p className="text-sm font-medium text-stone-600">Loading your memories...</p>
            </div>
          ) : memories.length === 0 ? (
            <EmptyState
              onCreateFirst={handleOpenCreate}
              onLoadStarterMemories={handleResetSampleMemories}
              isLoadingStarter={isSeedingStarter}
            />
          ) : filteredAndSortedMemories.length === 0 ? (
            <div className="py-16 text-center bg-white border border-stone-200 rounded-xl p-8">
              <p className="text-base font-semibold text-stone-800">No matching memories</p>
              <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                No memories match "{searchQuery}". Try a different search term or clear the filter.
              </p>
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="mt-4 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-700 text-xs font-medium transition-colors"
              >
                Clear Search
              </button>
            </div>
          ) : (
            <div className="relative pl-4 sm:pl-6 border-l-2 border-stone-200 space-y-6">
              {filteredAndSortedMemories.map((memory) => (
                <div key={memory.id} className="relative group">
                  {/* Timeline node bullet */}
                  <div
                    className="absolute -left-[23px] sm:-left-[31px] top-6 w-3.5 h-3.5 rounded-full bg-white border-2 border-stone-400 group-hover:border-stone-900 transition-colors"
                    aria-hidden="true"
                  />
                  <MemoryCard
                    memory={memory}
                    onEdit={handleOpenEdit}
                    onDelete={handleOpenDelete}
                    onConverseClick={handleConverseClick}
                    onDeleteReflection={handleDeleteReflection}
                  />
                </div>
              ))}
            </div>
          )}
        </main>
      )}

      {/* Footer */}
      <footer className="border-t border-stone-200 bg-white py-4 mt-auto">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 flex items-center justify-between text-xs text-stone-500">
          <span>Gemini Journal</span>
          <span className="text-stone-400">Private &amp; Personal</span>
        </div>
      </footer>

      {/* Create / Edit Memory Modal */}
      <MemoryModal
        isOpen={isModalOpen}
        mode={modalMode}
        initialData={activeMemory}
        isSaving={isSavingMemory}
        onSave={handleSaveMemory}
        onClose={() => {
          if (!isSavingMemory) {
            setIsModalOpen(false);
            setActiveMemory(null);
          }
        }}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={isDeleteOpen}
        memory={memoryToDelete}
        isDeleting={isDeletingMemory}
        onConfirm={handleConfirmDelete}
        onCancel={() => {
          if (!isDeletingMemory) {
            setIsDeleteOpen(false);
            setMemoryToDelete(null);
          }
        }}
      />

      {/* Toast Feedback */}
      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </div>
  );
}

