import React, { useState } from 'react';
import { signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from '../firebase.ts';
import { BookOpen, ShieldCheck, AlertCircle, Loader2, LogIn, ExternalLink } from 'lucide-react';

interface AuthScreenProps {
  onSuccess?: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = () => {
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const getFriendlyErrorMessage = (err: any): string => {
    const code = err?.code || '';
    switch (code) {
      case 'auth/popup-closed-by-user':
        return 'The sign-in window was closed before completing authentication. Please click the button to try again.';
      case 'auth/popup-blocked':
        return 'The sign-in popup was blocked by your browser. Please allow popups for this window, or open the application in a new tab using the icon in the top right.';
      case 'auth/cancelled-popup-request':
        return 'A sign-in request is already in progress. Please complete or dismiss the existing window.';
      case 'auth/network-request-failed':
        return 'Network connection error. Please verify your internet connection and try again.';
      case 'auth/unauthorized-domain':
        return 'This domain is not in the Firebase Authentication authorized domains list.';
      default:
        return err?.message || 'An unexpected error occurred during Google sign-in. Please try again.';
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setIsLoading(true);

    try {
      await signInWithPopup(auth, googleProvider);
      // onAuthStateChanged in App.tsx will automatically detect the authenticated user
    } catch (err: any) {
      setError(getFriendlyErrorMessage(err));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        {/* Brand Icon */}
        <div className="flex justify-center">
          <div className="w-12 h-12 rounded-2xl bg-stone-900 flex items-center justify-center text-white shadow-xs">
            <BookOpen className="w-6 h-6 text-stone-100" />
          </div>
        </div>

        {/* Title */}
        <h2 className="mt-4 text-center text-2xl font-semibold tracking-tight text-stone-900">
          Gemini Journal
        </h2>
        <p className="mt-1 text-center text-xs text-stone-500 max-w">
          Private, chronological reflection journal
        </p>

        <div className="mt-2 flex items-center justify-center gap-1.5 text-xs text-stone-500">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Private & Authenticated with Google</span>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        <div className="bg-white py-8 px-6 sm:px-10 shadow-xs border border-stone-200 rounded-2xl">
          {/* Header */}
          <div className="mb-6 text-center">
            <h3 className="text-lg font-medium text-stone-900">
              Sign in to your journal
            </h3>
            <p className="text-xs text-stone-500 mt-1 leading-relaxed">
              Authenticate using your Google account to access your private memories and timeline.
            </p>
          </div>

          {/* Error Banner */}
          {error && (
            <div
              id="auth-error-banner"
              className="mb-5 p-3 rounded-xl bg-red-50 border border-red-200 flex items-start gap-2.5 text-xs text-red-700"
            >
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{error}</div>
            </div>
          )}

          {/* Google Sign In Button */}
          <div className="space-y-3">
            <button
              id="google-sign-in-btn"
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full inline-flex items-center justify-center gap-3 py-3 px-4 rounded-xl text-sm font-medium text-stone-800 bg-white border border-stone-300 hover:bg-stone-50 hover:border-stone-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-stone-900 shadow-2xs transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-stone-500" />
                  <span>Connecting to Google...</span>
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4 text-stone-700" />
                  <span>Continue with Google</span>
                </>
              )}
            </button>
          </div>

          {/* Helpful Preview Note */}
          <div className="mt-6 border-t border-stone-100 pt-4 text-center">
            <div className="flex items-center justify-center gap-1.5 text-2xs text-stone-400">
              <ExternalLink className="w-3 h-3" />
              <span>Uses secure popup authentication</span>
            </div>
            <p className="mt-1 text-2xs text-stone-400 leading-relaxed">
              If your browser blocks the popup inside the preview frame, open the app in a new tab.
            </p>
          </div>
        </div>

        {/* Security Assurance */}
        <p className="mt-6 text-center text-xs text-stone-400 leading-relaxed px-4">
          Personal memories remain strictly private and isolated to your authenticated Google account.
        </p>
      </div>
    </div>
  );
};
