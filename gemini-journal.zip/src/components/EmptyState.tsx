import React from 'react';
import { BookOpen, Plus, Sparkles, Loader2 } from 'lucide-react';

interface EmptyStateProps {
  onCreateFirst: () => void;
  onLoadStarterMemories?: () => void;
  isLoadingStarter?: boolean;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  onCreateFirst,
  onLoadStarterMemories,
  isLoadingStarter = false,
}) => {
  return (
    <div
      id="empty-timeline-state"
      className="bg-white border border-dashed border-stone-300 rounded-2xl p-10 sm:p-12 text-center max-w-lg mx-auto my-12 shadow-2xs"
    >
      <div className="w-14 h-14 rounded-2xl bg-stone-100 border border-stone-200 flex items-center justify-center mx-auto mb-4 text-stone-500">
        <BookOpen className="w-7 h-7 stroke-[1.5]" />
      </div>
      <h3 className="text-lg font-semibold text-stone-900 mb-2">
        Your timeline is empty
      </h3>
      <p className="text-sm text-stone-600 leading-relaxed mb-6 max-w-md mx-auto">
        Gemini Journal is a private space to preserve authentic moments, feelings, and thoughts exactly as you remember them.
      </p>
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
        <button
          id="create-first-memory-btn"
          type="button"
          onClick={onCreateFirst}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-stone-900 text-white hover:bg-stone-800 transition-colors text-sm font-medium shadow-xs cursor-pointer focus:outline-none focus:ring-2 focus:ring-stone-400 focus:ring-offset-2"
        >
          <Plus className="w-4 h-4" />
          <span>Create Your First Memory</span>
        </button>

        {onLoadStarterMemories && (
          <button
            id="load-starter-memories-btn"
            type="button"
            onClick={onLoadStarterMemories}
            disabled={isLoadingStarter}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-stone-300 bg-white text-stone-700 hover:bg-stone-50 transition-colors text-sm font-medium shadow-2xs cursor-pointer disabled:opacity-50"
          >
            {isLoadingStarter ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-stone-500" />
                <span>Loading...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-stone-500" />
                <span>Load Starter Memories</span>
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};

