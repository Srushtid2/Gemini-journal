import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Sparkles,
  ArrowLeft,
  X,
  Calendar,
  AlertCircle,
  BookOpen,
  ChevronDown,
  ChevronUp,
  Plus,
  Loader2,
} from 'lucide-react';
import { Memory, ChatMessage } from '../types.ts';

interface GeminiChatProps {
  focusedMemory: Memory | null;
  allMemories: Memory[];
  messages: ChatMessage[];
  isLoading: boolean;
  error: string | null;
  onSendMessage: (text: string) => Promise<void>;
  onClearFocus: () => void;
  onBackToTimeline: () => void;
  onNewConversation: () => void;
}

export const GeminiChat: React.FC<GeminiChatProps> = ({
  focusedMemory,
  allMemories,
  messages,
  isLoading,
  error,
  onSendMessage,
  onClearFocus,
  onBackToTimeline,
  onNewConversation,
}) => {
  const [inputText, setInputText] = useState('');
  const [showOriginalMemory, setShowOriginalMemory] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Auto-scroll to bottom of conversation
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Focus input on mount or when focus changes
  useEffect(() => {
    if (!isLoading) {
      inputRef.current?.focus();
    }
  }, [focusedMemory, isLoading]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed || isLoading) return;

    setInputText('');
    await onSendMessage(trimmed);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isLoading && inputText.trim()) {
        handleSend(e);
      }
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4.5rem)] max-w-3xl mx-auto w-full bg-white sm:border sm:border-stone-200 sm:rounded-2xl shadow-xs overflow-hidden">
      {/* Top Header & Navigation Bar */}
      <div className="border-b border-stone-200 bg-stone-50/75 px-4 sm:px-6 py-3 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2">
          <button
            id="back-to-timeline-btn"
            type="button"
            onClick={onBackToTimeline}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-200 bg-white hover:bg-stone-100 text-stone-700 text-xs font-medium transition-colors cursor-pointer"
            title="Return to My Timeline"
          >
            <ArrowLeft className="w-3.5 h-3.5 text-stone-600" />
            <span>Timeline</span>
          </button>
          <div className="h-4 w-px bg-stone-200 mx-1 hidden sm:block" />
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-stone-900 text-white flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-stone-200" />
            </div>
            <h2 className="text-sm font-semibold text-stone-900">Gemini Chat</h2>
          </div>
        </div>

        {/* Clear & New Conversation Action */}
        <div className="flex items-center gap-2">
          <button
            id="new-conversation-btn"
            type="button"
            onClick={onNewConversation}
            disabled={messages.length === 0 && !error}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-200 bg-white hover:bg-stone-100 disabled:opacity-40 disabled:hover:bg-white disabled:cursor-not-allowed text-stone-700 text-xs font-medium transition-colors cursor-pointer shadow-2xs"
            title="Start a new conversation and clear chat history"
          >
            <Plus className="w-3.5 h-3.5 text-stone-600" />
            <span>New conversation</span>
          </button>
        </div>
      </div>

      {/* Focus Status Banner */}
      <div className="bg-stone-100/90 border-b border-stone-200 px-4 sm:px-6 py-3 shrink-0 transition-colors">
        {focusedMemory ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 text-xs font-semibold text-stone-800">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  <span className="truncate">
                    Conversing about: <span className="underline decoration-stone-300">{focusedMemory.title}</span>
                  </span>
                </div>
                <div className="inline-flex items-center gap-1.5 text-[11px] text-stone-500 font-mono mt-0.5">
                  <Calendar className="w-3 h-3 text-stone-400" />
                  <span>{focusedMemory.date}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowOriginalMemory((prev) => !prev)}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded border border-stone-200 bg-white hover:bg-stone-50 text-[11px] font-medium text-stone-600 transition-colors cursor-pointer"
                >
                  <span>{showOriginalMemory ? 'Hide text' : 'View memory text'}</span>
                  {showOriginalMemory ? (
                    <ChevronUp className="w-3 h-3 text-stone-400" />
                  ) : (
                    <ChevronDown className="w-3 h-3 text-stone-400" />
                  )}
                </button>
                <button
                  id="clear-focus-btn"
                  type="button"
                  onClick={onClearFocus}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-stone-200 hover:bg-stone-300 text-stone-700 text-xs font-medium transition-colors cursor-pointer"
                  title="Clear focused memory and converse across all memories"
                >
                  <X className="w-3 h-3 text-stone-600" />
                  <span>Clear focus</span>
                </button>
              </div>
            </div>

            {/* Expandable original memory text viewer */}
            {showOriginalMemory && (
              <div className="mt-2 p-3 bg-white rounded-lg border border-stone-200 text-xs text-stone-700 leading-relaxed font-sans max-h-40 overflow-y-auto whitespace-pre-wrap animate-in fade-in duration-100">
                <div className="text-[10px] font-semibold uppercase tracking-wider text-stone-400 mb-1">
                  Original Memory Text (Verbatim Context)
                </div>
                {focusedMemory.originalText}

                {focusedMemory.reflection && (
                  <div className="mt-2.5 pt-2.5 border-t border-stone-200 text-xs text-stone-600 italic">
                    <div className="text-[10px] font-semibold not-italic uppercase tracking-wider text-stone-400 mb-1 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-stone-500" />
                      <span>Saved Gemini Reflection</span>
                    </div>
                    "{focusedMemory.reflection}"
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-between gap-2 text-xs text-stone-600">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
              <span>
                Not focused on one memory &bull; Conversing across all{' '}
                <span className="font-semibold text-stone-800">{allMemories.length}</span> journal memories
              </span>
            </div>
            <button
              type="button"
              onClick={onBackToTimeline}
              className="text-[11px] text-stone-600 hover:text-stone-900 underline font-medium cursor-pointer"
            >
              Select memory from Timeline
            </button>
          </div>
        )}
      </div>

      {/* Messages List Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-stone-50/40">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 max-w-md mx-auto my-auto">
            <div className="w-12 h-12 rounded-2xl bg-white border border-stone-200 shadow-2xs flex items-center justify-center text-stone-700 mb-3">
              <BookOpen className="w-6 h-6 stroke-[1.5]" />
            </div>
            <h3 className="text-base font-semibold text-stone-900 mb-1">
              {focusedMemory ? `Questions about "${focusedMemory.title}"` : 'Chat about your journal'}
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed mb-4">
              {focusedMemory
                ? 'Ask questions about details, observations, or moments recorded in this memory.'
                : 'Ask questions or explore themes across your saved journal memories.'}
            </p>
            <div className="bg-white border border-stone-200 rounded-xl p-3 text-[11px] text-stone-500 text-left space-y-1 w-full">
              <div className="font-semibold text-stone-700 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-stone-400" />
                <span>Accuracy & Privacy Principles</span>
              </div>
              <ul className="list-disc pl-4 space-y-0.5 text-stone-600">
                <li>Gemini never invents facts not present in your memories.</li>
                <li>If details are missing, Gemini states they are not recorded.</li>
                <li>Zero emotion diagnosis, unsolicited advice, or forced optimism.</li>
              </ul>
            </div>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.role === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[78%] px-4 py-3 rounded-2xl text-sm leading-relaxed shadow-2xs ${
                  msg.role === 'user'
                    ? 'bg-stone-900 text-white rounded-tr-xs'
                    : 'bg-white border border-stone-200 text-stone-800 rounded-tl-xs'
                }`}
              >
                <div className="whitespace-pre-wrap break-words font-sans">
                  {msg.content}
                </div>
              </div>
              <span className="text-[10px] text-stone-400 px-2 mt-1 font-mono">
                {msg.role === 'user' ? 'You' : 'Gemini'}
              </span>
            </div>
          ))
        )}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex flex-col items-start animate-in fade-in duration-150">
            <div className="bg-white border border-stone-200 text-stone-700 px-4 py-3 rounded-2xl rounded-tl-xs text-sm flex items-center gap-2.5 shadow-2xs">
              <Loader2 className="w-4 h-4 text-stone-500 animate-spin" />
              <span className="text-xs text-stone-600">
                Reviewing memory context...
              </span>
            </div>
            <span className="text-[10px] text-stone-400 px-2 mt-1 font-mono">
              Gemini
            </span>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2.5 animate-in fade-in duration-150">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold">Unable to complete response</p>
              <p className="mt-0.5 text-red-600">{error}</p>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Message Input Form */}
      <form
        onSubmit={handleSend}
        className="p-3 sm:p-4 bg-white border-t border-stone-200 flex items-center gap-2 shrink-0"
      >
        <input
          ref={inputRef}
          id="chat-input"
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={
            isLoading
              ? 'Gemini is responding...'
              : focusedMemory
              ? `Ask a question about "${focusedMemory.title}"...`
              : 'Ask a question about your journal memories...'
          }
          disabled={isLoading}
          className="flex-1 px-4 py-2.5 rounded-xl border border-stone-300 text-stone-900 text-sm placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-400 focus:border-stone-400 disabled:opacity-60 disabled:bg-stone-50"
        />
        <button
          id="chat-send-btn"
          type="submit"
          disabled={!inputText.trim() || isLoading}
          className="inline-flex items-center justify-center p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-stone-900 text-white hover:bg-stone-800 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-sm font-medium cursor-pointer shadow-xs focus:outline-none focus:ring-2 focus:ring-stone-400"
          aria-label="Send message"
        >
          <Send className="w-4 h-4 sm:mr-1.5" />
          <span className="hidden sm:inline">Send</span>
        </button>
      </form>
    </div>
  );
};
