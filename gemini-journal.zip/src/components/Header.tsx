import React from 'react';
import { Plus, BookOpen, ShieldCheck, Sparkles, LogOut, User as UserIcon } from 'lucide-react';

interface HeaderProps {
  currentView: 'timeline' | 'chat';
  onNavigate: (view: 'timeline' | 'chat') => void;
  onNewMemory: () => void;
  memoryCount: number;
  userEmail?: string | null;
  onSignOut?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  onNewMemory,
  memoryCount,
  userEmail,
  onSignOut,
}) => {
  return (
    <header className="border-b border-stone-200 bg-white sticky top-0 z-20 shadow-2xs">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Brand & Identity */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('timeline')}
            className="w-10 h-10 rounded-xl bg-stone-900 flex items-center justify-center text-white shadow-xs cursor-pointer hover:bg-stone-800 transition-colors shrink-0"
            title="Go to Timeline"
          >
            <BookOpen className="w-5 h-5 text-stone-100" />
          </button>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <button
                type="button"
                id="header-app-title"
                onClick={() => onNavigate('timeline')}
                className="text-lg sm:text-xl font-semibold tracking-tight text-stone-900 hover:text-stone-700 transition-colors text-left cursor-pointer whitespace-nowrap"
              >
                Gemini Journal
              </button>
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-stone-100 text-stone-600 border border-stone-200 whitespace-nowrap">
                <ShieldCheck className="w-3 h-3 text-stone-500" />
                <span>Private &amp; Local</span>
              </span>
            </div>
            <p className="text-xs text-stone-500 font-normal whitespace-nowrap truncate">
              Chronological Timeline &bull; {memoryCount} {memoryCount === 1 ? 'memory' : 'memories'}
            </p>
          </div>
        </div>

        {/* Navigation & Actions Group */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Navigation Pill */}
          <nav
            aria-label="Journal Navigation"
            className="flex items-center p-1 bg-stone-100 border border-stone-200 rounded-lg text-xs font-medium shrink-0"
          >
            <button
              id="nav-timeline-btn"
              type="button"
              onClick={() => onNavigate('timeline')}
              className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                currentView === 'timeline'
                  ? 'bg-white text-stone-900 shadow-2xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Timeline
            </button>
            <button
              id="nav-chat-btn"
              type="button"
              onClick={() => onNavigate('chat')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                currentView === 'chat'
                  ? 'bg-white text-stone-900 shadow-2xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-stone-600" />
              <span>Gemini Chat</span>
            </button>
          </nav>

          {/* Primary Action Button */}
          <button
            id="new-memory-btn"
            type="button"
            onClick={onNewMemory}
            className="inline-flex items-center gap-1.5 sm:gap-2 px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-lg bg-stone-900 text-white hover:bg-stone-800 transition-colors text-xs sm:text-sm font-medium shadow-xs focus:outline-none focus:ring-2 focus:ring-stone-400 focus:ring-offset-2 cursor-pointer whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">New Memory</span>
            <span className="sm:hidden">New</span>
          </button>

          {/* User Email & Sign Out */}
          {userEmail && (
            <div className="flex items-center pl-2 sm:pl-3 border-l border-stone-200 gap-2 shrink-0">
              <div
                className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-stone-100 border border-stone-200/80 text-stone-700 text-xs font-medium max-w-[170px] xl:max-w-[220px]"
                title={userEmail}
              >
                <UserIcon className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                <span className="truncate">{userEmail}</span>
              </div>
              <button
                id="sign-out-btn"
                type="button"
                onClick={onSignOut}
                className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg border border-stone-200 bg-white hover:bg-stone-100 text-stone-600 hover:text-stone-900 text-xs font-medium transition-colors cursor-pointer shadow-2xs whitespace-nowrap"
                title={`Sign out (${userEmail})`}
              >
                <LogOut className="w-3.5 h-3.5 text-stone-500" />
                <span className="hidden md:inline">Sign Out</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};


