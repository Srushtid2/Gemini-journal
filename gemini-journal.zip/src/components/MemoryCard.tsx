import React from 'react';
import { Calendar, Pencil, Trash2, MessageSquare, Image, Video, Sparkles } from 'lucide-react';
import { Memory } from '../types.ts';

interface MemoryCardProps {
  memory: Memory;
  onEdit: (memory: Memory) => void;
  onDelete: (memory: Memory) => void;
  onConverseClick: (memory: Memory) => void;
  onDeleteReflection?: (memory: Memory) => void;
}

export const MemoryCard: React.FC<MemoryCardProps> = ({
  memory,
  onEdit,
  onDelete,
  onConverseClick,
  onDeleteReflection,
}) => {
  // Format date cleanly
  const formatDate = (dateStr: string) => {
    try {
      const [year, month, day] = dateStr.split('-').map(Number);
      if (!year || !month || !day) return dateStr;
      const date = new Date(year, month - 1, day);
      return date.toLocaleDateString('en-US', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <article
      id={`memory-card-${memory.id}`}
      className="bg-white border border-stone-200 rounded-xl p-6 transition-all hover:border-stone-300 shadow-xs flex flex-col gap-4"
    >
      {/* Date & Meta Header */}
      <div className="flex items-center justify-between gap-2 border-b border-stone-100 pb-3">
        <div className="inline-flex items-center gap-2 text-stone-600 text-sm font-medium">
          <Calendar className="w-4 h-4 text-stone-400" />
          <time dateTime={memory.date}>{formatDate(memory.date)}</time>
        </div>
        <span className="text-xs font-mono text-stone-400">
          {memory.date}
        </span>
      </div>

      {/* Title */}
      <h2
        id={`memory-title-${memory.id}`}
        className="text-lg font-semibold text-stone-900 tracking-tight leading-snug"
      >
        {memory.title}
      </h2>

      {/* Original Memory Text: Preserved exactly, no modification */}
      <div className="text-stone-700 text-base leading-relaxed whitespace-pre-wrap break-words font-normal">
        {memory.originalText}
      </div>

      {/* Media Attachments */}
      {memory.temporaryMedia && memory.temporaryMedia.length > 0 && (
        <div className="space-y-3 pt-1">
          {memory.temporaryMedia.map((att) => (
            <div
              key={att.id}
              className="rounded-xl border border-stone-200 overflow-hidden bg-stone-50/50"
            >
              {att.type === 'image' ? (
                <div className="bg-stone-900/5 flex items-center justify-center max-h-80 overflow-hidden">
                  <img
                    src={att.url}
                    alt={att.name}
                    className="max-h-80 w-full object-contain"
                  />
                </div>
              ) : (
                <div className="bg-black flex items-center justify-center">
                  <video
                    src={att.url}
                    controls
                    className="max-h-80 w-full"
                  />
                </div>
              )}
              <div className="px-3.5 py-2 bg-white border-t border-stone-200/80 flex items-center justify-between gap-2 text-xs">
                <span className="font-medium text-stone-700 truncate">
                  {att.name}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Media Placeholders: UI indicators only for mock/empty session memories */}
      {(!memory.temporaryMedia || memory.temporaryMedia.length === 0) &&
        (memory.hasPhotoPlaceholder || memory.hasVideoPlaceholder) && (
          <div className="pt-2 flex flex-wrap gap-2">
            {memory.hasPhotoPlaceholder && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-stone-100 border border-stone-200 text-xs font-medium text-stone-600">
                <Image className="w-3.5 h-3.5 text-stone-500" />
                <span>Photo Attachment</span>
              </div>
            )}
            {memory.hasVideoPlaceholder && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-stone-100 border border-stone-200 text-xs font-medium text-stone-600">
                <Video className="w-3.5 h-3.5 text-stone-500" />
                <span>Video Attachment</span>
              </div>
            )}
          </div>
        )}

      {/* AI Reflection Section: Clearly distinguished from original user content */}
      {memory.reflection && (
        <div
          id={`reflection-box-${memory.id}`}
          className="mt-1 rounded-xl bg-stone-50 border border-stone-200/90 p-4 sm:p-5 flex flex-col gap-2.5"
        >
          <div className="flex items-center justify-between gap-2 border-b border-stone-200/70 pb-2">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-800">
              <Sparkles className="w-3.5 h-3.5 text-stone-700" />
              <span>Gemini Reflection</span>
            </div>
            <div className="flex items-center gap-2.5">
              {memory.reflectionGeneratedAt && (
                <span className="text-[11px] font-mono text-stone-400">
                  {new Date(memory.reflectionGeneratedAt).toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                  })}
                </span>
              )}
              {onDeleteReflection && (
                <button
                  type="button"
                  onClick={() => onDeleteReflection(memory)}
                  className="text-[11px] text-stone-400 hover:text-red-600 transition-colors cursor-pointer"
                  title="Remove reflection"
                >
                  Remove
                </button>
              )}
            </div>
          </div>
          <div className="text-stone-700 text-sm leading-relaxed whitespace-pre-wrap font-normal italic">
            "{memory.reflection}"
          </div>
          <div className="text-[10px] text-stone-400 font-sans mt-0.5">
            AI reflection grounded in this memory &bull; Original journal text remains untouched
          </div>
        </div>
      )}

      {/* Card Actions Footer */}
      <div className="mt-2 pt-4 border-t border-stone-100 flex items-center justify-between gap-3 flex-wrap">
        {/* Converse Button */}
        <div className="flex items-center gap-2">
          <button
            id={`converse-memory-btn-${memory.id}`}
            type="button"
            onClick={() => onConverseClick(memory)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-800 text-xs font-medium transition-colors cursor-pointer shadow-2xs hover:border-stone-300"
            title="Converse with Gemini about this memory"
          >
            <MessageSquare className="w-3.5 h-3.5 text-stone-600" />
            <span>Converse</span>
          </button>
        </div>

        {/* Edit & Delete Buttons */}
        <div className="flex items-center gap-2">
          <button
            id={`edit-memory-btn-${memory.id}`}
            type="button"
            onClick={() => onEdit(memory)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-200 text-stone-700 hover:bg-stone-100 hover:text-stone-900 text-xs font-medium transition-colors cursor-pointer"
          >
            <Pencil className="w-3.5 h-3.5 text-stone-500" />
            <span>Edit</span>
          </button>
          <button
            id={`delete-memory-btn-${memory.id}`}
            type="button"
            onClick={() => onDelete(memory)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 text-xs font-medium transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete</span>
          </button>
        </div>
      </div>
    </article>
  );
};

