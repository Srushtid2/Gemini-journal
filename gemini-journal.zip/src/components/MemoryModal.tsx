import React, { useState, useEffect, useRef } from 'react';
import { X, Image as ImageIcon, Video as VideoIcon, Calendar, AlertCircle, Loader2, Trash2 } from 'lucide-react';
import { Memory, MemoryFormData, TemporaryMediaAttachment } from '../types.ts';

interface MemoryModalProps {
  isOpen: boolean;
  mode: 'create' | 'edit';
  initialData?: Memory | null;
  isSaving?: boolean;
  onSave: (data: MemoryFormData) => void;
  onClose: () => void;
}

export const MemoryModal: React.FC<MemoryModalProps> = ({
  isOpen,
  mode,
  initialData,
  isSaving = false,
  onSave,
  onClose,
}) => {
  const getTodayString = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const [date, setDate] = useState<string>(getTodayString());
  const [title, setTitle] = useState<string>('');
  const [originalText, setOriginalText] = useState<string>('');
  const [temporaryMedia, setTemporaryMedia] = useState<TemporaryMediaAttachment[]>([]);
  const [error, setError] = useState<string | null>(null);

  const newlyCreatedUrlsRef = useRef<string[]>([]);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      newlyCreatedUrlsRef.current = [];
      if (mode === 'edit' && initialData) {
        setDate(initialData.date);
        setTitle(initialData.title);
        setOriginalText(initialData.originalText);
        setTemporaryMedia(initialData.temporaryMedia ? [...initialData.temporaryMedia] : []);
      } else {
        setDate(getTodayString());
        setTitle('');
        setOriginalText('');
        setTemporaryMedia([]);
      }
      setError(null);
    }
  }, [isOpen, mode, initialData]);

  if (!isOpen) return null;

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video') => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Reset native input so selecting the same file triggers change
    e.target.value = '';

    if (type === 'image') {
      if (!file.type.startsWith('image/')) {
        setError('Please select a valid image file (PNG, JPG, WebP, GIF).');
        return;
      }
      if (file.size > 25 * 1024 * 1024) {
        setError('Image exceeds maximum size limit of 25 MB.');
        return;
      }
    } else if (type === 'video') {
      if (!file.type.startsWith('video/')) {
        setError('Please select a valid video file (MP4, WebM, MOV).');
        return;
      }
      if (file.size > 75 * 1024 * 1024) {
        setError('Video exceeds maximum size limit of 75 MB.');
        return;
      }
    }

    try {
      const objectUrl = URL.createObjectURL(file);
      newlyCreatedUrlsRef.current.push(objectUrl);

      const attachment: TemporaryMediaAttachment = {
        id: `media-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        type,
        url: objectUrl,
        name: file.name,
        size: file.size,
        createdAt: Date.now(),
      };

      setTemporaryMedia((prev) => [...prev, attachment]);
      setError(null);
    } catch (err: any) {
      setError('Failed to load media preview: ' + (err?.message || 'Unknown error'));
    }
  };

  const handleRemoveAttachment = (attachmentId: string) => {
    setTemporaryMedia((prev) => {
      const target = prev.find((m) => m.id === attachmentId);
      if (target) {
        URL.revokeObjectURL(target.url);
        newlyCreatedUrlsRef.current = newlyCreatedUrlsRef.current.filter((u) => u !== target.url);
      }
      return prev.filter((m) => m.id !== attachmentId);
    });
  };

  const handleCloseModal = () => {
    // Revoke any object URLs that were created in this uncommitted modal session
    newlyCreatedUrlsRef.current.forEach((url) => {
      URL.revokeObjectURL(url);
    });
    newlyCreatedUrlsRef.current = [];
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please provide a title for this memory.');
      return;
    }
    if (!originalText.trim()) {
      setError('Please enter your original memory text.');
      return;
    }
    if (!date) {
      setError('Please select a date.');
      return;
    }

    // Clear newly created ref so handleClose doesn't revoke them
    newlyCreatedUrlsRef.current = [];

    onSave({
      date,
      title: title.trim(),
      originalText: originalText.trim(),
      hasPhotoPlaceholder: temporaryMedia.some((m) => m.type === 'image'),
      hasVideoPlaceholder: temporaryMedia.some((m) => m.type === 'video'),
      temporaryMedia,
    });
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-xs overflow-y-auto"
    >
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xl max-w-xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between">
          <h2 id="modal-title" className="text-lg font-semibold text-stone-900">
            {mode === 'create' ? 'New Memory' : 'Edit Memory'}
          </h2>
          <button
            type="button"
            id="modal-close-btn"
            onClick={handleCloseModal}
            className="text-stone-400 hover:text-stone-600 p-1.5 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5">
          {error && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          {/* Date Input */}
          <div>
            <label
              htmlFor="memory-date-input"
              className="block text-xs font-semibold uppercase tracking-wider text-stone-600 mb-1.5"
            >
              Date
            </label>
            <div className="relative">
              <input
                id="memory-date-input"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-stone-900 text-sm focus:outline-none focus:ring-2 focus:ring-stone-400 focus:border-stone-400"
              />
            </div>
          </div>

          {/* Title Input */}
          <div>
            <label
              htmlFor="memory-title-input"
              className="block text-xs font-semibold uppercase tracking-wider text-stone-600 mb-1.5"
            >
              Title
            </label>
            <input
              id="memory-title-input"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Give this memory a descriptive title..."
              required
              className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-stone-900 text-sm focus:outline-none focus:ring-2 focus:ring-stone-400 focus:border-stone-400 placeholder:text-stone-400"
            />
          </div>

          {/* Original Memory Text */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label
                htmlFor="memory-text-input"
                className="block text-xs font-semibold uppercase tracking-wider text-stone-600"
              >
                Original Memory Text
              </label>
              <span className="text-[11px] text-stone-400 font-mono">
                Preserved as written
              </span>
            </div>
            <textarea
              id="memory-text-input"
              value={originalText}
              onChange={(e) => setOriginalText(e.target.value)}
              placeholder="Write what happened, how it felt, or sensory details you want to preserve..."
              rows={5}
              required
              className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-stone-900 text-sm focus:outline-none focus:ring-2 focus:ring-stone-400 focus:border-stone-400 placeholder:text-stone-400 resize-y leading-relaxed"
            />
          </div>

          {/* Media Attachments */}
          <div className="space-y-3 pt-1">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold uppercase tracking-wider text-stone-600">
                Media Attachments
              </label>
            </div>

            {/* Hidden native file inputs */}
            <input
              ref={photoInputRef}
              id="photo-file-input"
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              onChange={(e) => handleFileSelected(e, 'image')}
              className="hidden"
            />
            <input
              ref={videoInputRef}
              id="video-file-input"
              type="file"
              accept="video/mp4,video/webm,video/quicktime"
              onChange={(e) => handleFileSelected(e, 'video')}
              className="hidden"
            />

            {/* Action buttons to trigger device selection */}
            <div className="flex items-center gap-2.5">
              <button
                id="select-photo-btn"
                type="button"
                onClick={() => photoInputRef.current?.click()}
                className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-700 text-xs font-medium transition-colors cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5 text-stone-500" />
                <span>Select Photo</span>
              </button>
              <button
                id="select-video-btn"
                type="button"
                onClick={() => videoInputRef.current?.click()}
                className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-stone-200 bg-stone-50 hover:bg-stone-100 text-stone-700 text-xs font-medium transition-colors cursor-pointer"
              >
                <VideoIcon className="w-3.5 h-3.5 text-stone-500" />
                <span>Select Video</span>
              </button>
            </div>

            {/* Attachment Preview List */}
            {temporaryMedia.length > 0 && (
              <div className="space-y-2.5 mt-2">
                {temporaryMedia.map((att) => (
                  <div
                    key={att.id}
                    className="rounded-xl border border-stone-200 bg-stone-50/70 p-3 flex flex-col gap-2"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        {att.type === 'image' ? (
                          <ImageIcon className="w-4 h-4 text-stone-600 shrink-0" />
                        ) : (
                          <VideoIcon className="w-4 h-4 text-stone-600 shrink-0" />
                        )}
                        <span className="text-xs font-medium text-stone-800 truncate max-w-[200px] sm:max-w-xs">
                          {att.name}
                        </span>
                        <span className="text-[11px] text-stone-400 font-mono shrink-0">
                          ({formatBytes(att.size)})
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveAttachment(att.id)}
                        className="text-stone-400 hover:text-red-600 p-1 rounded-md hover:bg-stone-100 transition-colors cursor-pointer shrink-0"
                        title="Remove attachment"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Media Preview Player/Viewer */}
                    <div className="overflow-hidden rounded-lg border border-stone-200 bg-white">
                      {att.type === 'image' ? (
                        <img
                          src={att.url}
                          alt={att.name}
                          className="max-h-48 w-full object-contain bg-stone-900/5"
                        />
                      ) : (
                        <video
                          src={att.url}
                          controls
                          className="max-h-48 w-full bg-black"
                        />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Modal Footer Actions */}
          <div className="pt-4 border-t border-stone-200 flex items-center justify-end gap-3">
            <button
              id="modal-cancel-btn"
              type="button"
              onClick={handleCloseModal}
              disabled={isSaving}
              className="px-4 py-2 rounded-lg border border-stone-300 text-stone-700 hover:bg-stone-100 text-sm font-medium transition-colors cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              id="modal-save-btn"
              type="submit"
              disabled={isSaving}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-stone-900 text-white hover:bg-stone-800 disabled:bg-stone-700 text-sm font-medium transition-colors cursor-pointer shadow-xs focus:outline-none focus:ring-2 focus:ring-stone-400 focus:ring-offset-2 disabled:cursor-not-allowed"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-stone-300" />
                  <span>Saving...</span>
                </>
              ) : (
                <span>Save Memory</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

