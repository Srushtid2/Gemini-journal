import { Memory } from '../types.ts';

export const INITIAL_MEMORIES: Memory[] = [
  {
    id: 'mem-1',
    date: '2026-08-28',
    title: 'Morning hike along the Redwood Creek trail',
    originalText: 'The coastal redwoods were shrouded in cool morning mist when we stepped onto the trail. The silence was absolute except for the occasional raven calling from the high canopy. Took a deep breath of wet pine needles, damp loam, and sea fog. It was one of those rare mornings where the noise in my head went quiet and I felt completely settled in the present.',
    hasPhotoPlaceholder: true,
    hasVideoPlaceholder: false,
    createdAt: 1787904000000,
  },
  {
    id: 'mem-2',
    date: '2026-07-15',
    title: "Grandma's braided cardamom bread recipe",
    originalText: "Spent four hours in the kitchen with Mom trying to capture Grandma's cardamom loaf recipe on paper. There was never an exact measurement written down—just 'until the dough pulls soft and smooth from the ceramic bowl'. We dusted the butcher block with flour, shaped three braids, and watched them rise under linen towels. By dusk, the entire home smelled of crushed green cardamom pods, sweet yeast, and warm butter.",
    hasPhotoPlaceholder: true,
    hasVideoPlaceholder: true,
    createdAt: 1784097600000,
  },
  {
    id: 'mem-3',
    date: '2026-06-02',
    title: 'Late evening train arriving into Kyoto',
    originalText: 'Steady summer rain drumming rhythmically against the train window as neon signs of the outer districts blurred past in amber and teal. Bought a can of hot roasted barley tea from the platform dispenser during the brief connection. Sat quietly listening to the gentle hum of the electric motor, jotting down a few stray observations in my notebook before pulling into Kyoto station.',
    hasPhotoPlaceholder: false,
    hasVideoPlaceholder: false,
    createdAt: 1780387200000,
  },
];
