import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  Unsubscribe,
  writeBatch,
} from 'firebase/firestore';
import { db } from '../firebase.ts';
import { Memory, MemoryFormData } from '../types.ts';
import { INITIAL_MEMORIES } from '../data/mockMemories.ts';

/**
 * Strict Undefined-Stripping & Zero-Media Hygiene
 * Ensures no undefined values, Base64 strings, or media blobs ever reach Firestore drivers.
 */
export function sanitizeFirestorePayload<T extends Record<string, any>>(obj: T): Partial<T> {
  const clean: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) {
      if (key === 'temporaryMedia' || key === 'media') {
        // Explicitly drop in-memory temporary attachments from database payloads
        continue;
      }
      if (typeof value === 'string' && value.startsWith('data:')) {
        throw new Error(`Security Violation: Base64 data detected in field "${key}". Media cannot be written to Firestore.`);
      }
      clean[key] = value;
    }
  }
  return clean as Partial<T>;
}

/**
 * Subscribe to the current authenticated user's memories in Firestore.
 * Listens for real-time changes and returns an unsubscribe function.
 */
export function subscribeToUserMemories(
  userId: string,
  onMemoriesUpdated: (memories: Memory[]) => void,
  onError: (error: Error) => void
): Unsubscribe {
  if (!userId) {
    onMemoriesUpdated([]);
    return () => {};
  }

  const memoriesCollectionRef = collection(db, 'users', userId, 'memories');
  const memoriesQuery = query(memoriesCollectionRef, orderBy('date', 'desc'));

  return onSnapshot(
    memoriesQuery,
    (snapshot) => {
      const memories: Memory[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        memories.push({
          id: docSnap.id,
          userId: data.userId || userId,
          date: data.date || '',
          title: data.title || 'Untitled Memory',
          originalText: data.originalText || '',
          reflection: data.reflection || null,
          reflectionGeneratedAt: typeof data.reflectionGeneratedAt === 'number' ? data.reflectionGeneratedAt : null,
          hasPhotoPlaceholder: Boolean(data.hasPhotoPlaceholder),
          hasVideoPlaceholder: Boolean(data.hasVideoPlaceholder),
          createdAt: typeof data.createdAt === 'number' ? data.createdAt : Date.now(),
          updatedAt: typeof data.updatedAt === 'number' ? data.updatedAt : undefined,
        });
      });

      onMemoriesUpdated(memories);
    },
    (err) => {
      console.error('Error listening to user memories:', err);
      onError(err);
    }
  );
}

/**
 * Create a new memory in the user's isolated Firestore collection.
 */
export async function createMemoryInFirestore(
  userId: string,
  formData: MemoryFormData
): Promise<Memory> {
  if (!userId) {
    throw new Error('Cannot create memory: User is not authenticated.');
  }

  const memoriesCollectionRef = collection(db, 'users', userId, 'memories');
  const newDocRef = doc(memoriesCollectionRef);
  const now = Date.now();

  const memoryPayload: Memory = {
    id: newDocRef.id,
    userId,
    date: formData.date,
    title: formData.title.trim(),
    originalText: formData.originalText.trim(),
    hasPhotoPlaceholder: Boolean(formData.hasPhotoPlaceholder),
    hasVideoPlaceholder: Boolean(formData.hasVideoPlaceholder),
    createdAt: now,
    updatedAt: now,
  };

  const sanitized = sanitizeFirestorePayload(memoryPayload);
  await setDoc(newDocRef, sanitized);

  return memoryPayload;
}

/**
 * Update an existing memory in the user's isolated Firestore collection.
 */
export async function updateMemoryInFirestore(
  userId: string,
  memoryId: string,
  formData: MemoryFormData
): Promise<void> {
  if (!userId) {
    throw new Error('Cannot update memory: User is not authenticated.');
  }
  if (!memoryId) {
    throw new Error('Cannot update memory: Memory ID is missing.');
  }

  const memoryDocRef = doc(db, 'users', userId, 'memories', memoryId);
  const updatePayload = sanitizeFirestorePayload({
    date: formData.date,
    title: formData.title.trim(),
    originalText: formData.originalText.trim(),
    hasPhotoPlaceholder: Boolean(formData.hasPhotoPlaceholder),
    hasVideoPlaceholder: Boolean(formData.hasVideoPlaceholder),
    updatedAt: Date.now(),
  });

  await updateDoc(memoryDocRef, updatePayload);
}

/**
 * Delete a memory from the user's isolated Firestore collection.
 */
export async function deleteMemoryFromFirestore(
  userId: string,
  memoryId: string
): Promise<void> {
  if (!userId) {
    throw new Error('Cannot delete memory: User is not authenticated.');
  }
  if (!memoryId) {
    throw new Error('Cannot delete memory: Memory ID is missing.');
  }

  const memoryDocRef = doc(db, 'users', userId, 'memories', memoryId);
  await deleteDoc(memoryDocRef);
}

/**
 * Seed initial starter memories into the authenticated user's Firestore collection.
 * Useful when a user's collection is empty so they immediately have starter memories.
 */
export async function seedStarterMemoriesInFirestore(userId: string): Promise<void> {
  if (!userId) {
    throw new Error('Cannot seed memories: User is not authenticated.');
  }

  const batch = writeBatch(db);
  const now = Date.now();

  INITIAL_MEMORIES.forEach((mockMem, index) => {
    // Generate distinct ID or retain clean ID prefixed with mem-
    const memRef = doc(db, 'users', userId, 'memories', `init-${index + 1}`);
    const payload = sanitizeFirestorePayload({
      id: memRef.id,
      userId,
      date: mockMem.date,
      title: mockMem.title,
      originalText: mockMem.originalText,
      hasPhotoPlaceholder: Boolean(mockMem.hasPhotoPlaceholder),
      hasVideoPlaceholder: Boolean(mockMem.hasVideoPlaceholder),
      createdAt: now - index * 1000,
      updatedAt: now,
    });
    batch.set(memRef, payload);
  });

  await batch.commit();
}

/**
 * Persist an AI-generated reflection to a memory document in Firestore.
 * Visually and structurally separated from the originalText.
 */
export async function saveMemoryReflection(
  userId: string,
  memoryId: string,
  reflection: string
): Promise<void> {
  if (!userId) {
    throw new Error('Cannot save reflection: User is not authenticated.');
  }
  if (!memoryId) {
    throw new Error('Cannot save reflection: Memory ID is missing.');
  }

  const memoryDocRef = doc(db, 'users', userId, 'memories', memoryId);
  const updatePayload = sanitizeFirestorePayload({
    reflection: reflection.trim(),
    reflectionGeneratedAt: Date.now(),
    updatedAt: Date.now(),
  });

  await updateDoc(memoryDocRef, updatePayload);
}

/**
 * Remove an AI-generated reflection from a memory document in Firestore.
 */
export async function deleteMemoryReflection(
  userId: string,
  memoryId: string
): Promise<void> {
  if (!userId) {
    throw new Error('Cannot delete reflection: User is not authenticated.');
  }
  if (!memoryId) {
    throw new Error('Cannot delete reflection: Memory ID is missing.');
  }

  const memoryDocRef = doc(db, 'users', userId, 'memories', memoryId);
  const updatePayload = sanitizeFirestorePayload({
    reflection: null,
    reflectionGeneratedAt: null,
    updatedAt: Date.now(),
  });

  await updateDoc(memoryDocRef, updatePayload);
}

