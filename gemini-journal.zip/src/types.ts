export interface TemporaryMediaAttachment {
  id: string;
  type: 'image' | 'video';
  url: string; // In-memory Object URL from URL.createObjectURL
  name: string;
  size: number;
  createdAt: number;
}

export interface Memory {
  id: string;
  userId?: string;
  date: string; // Format: YYYY-MM-DD
  title: string;
  originalText: string;
  reflection?: string | null;
  reflectionGeneratedAt?: number | null;
  hasPhotoPlaceholder?: boolean;
  hasVideoPlaceholder?: boolean;
  createdAt: number;
  updatedAt?: number;
  temporaryMedia?: TemporaryMediaAttachment[];
}

export interface MemoryFormData {
  date: string;
  title: string;
  originalText: string;
  hasPhotoPlaceholder?: boolean;
  hasVideoPlaceholder?: boolean;
  temporaryMedia?: TemporaryMediaAttachment[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
}

